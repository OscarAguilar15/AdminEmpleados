<?php

namespace Mpdf\Http\Exception;

class ForbiddenRequestException extends \Mpdf\MpdfException
{

}
